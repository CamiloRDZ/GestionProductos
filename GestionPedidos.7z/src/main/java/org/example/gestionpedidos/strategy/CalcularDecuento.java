package org.example.gestionpedidos.strategy;

public interface CalcularDecuento {

    double calcularDescuento(double precio);
}
