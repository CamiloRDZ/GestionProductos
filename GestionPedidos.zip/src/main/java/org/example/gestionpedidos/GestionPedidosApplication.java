package org.example.gestionpedidos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPedidosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPedidosApplication.class, args);
	}

}
